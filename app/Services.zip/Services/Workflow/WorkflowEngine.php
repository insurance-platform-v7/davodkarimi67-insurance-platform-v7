<?php

namespace App\Services\Workflow;

use App\Models\WorkflowLog;
use App\Models\WorkflowState;
use App\Models\WorkflowTransition;
use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class WorkflowEngine
{
    public function transition(Model $model, string $toStateCode): void
    {
        DB::transaction(function () use ($model, $toStateCode): void {
            $tenantId = $model->getAttribute('tenant_id');
            $entityType = $this->entityType($model);
            $currentState = $this->resolveCurrentState($model);

            [$fromState, $toState] = $this->resolveStates(
                $tenantId,
                $entityType,
                $currentState,
                $toStateCode
            );

            $transition = $this->resolveTransition(
                $tenantId,
                $entityType,
                $fromState,
                $toState
            );

            /** @var array<string, array<string, mixed>> $conditions */
            $conditions = $transition->conditions ?? [];

            $this->validateConditions($model, $conditions);

            $model->update([
                'status' => $toState->code,
            ]);

            /** @var array<int, array<string, mixed>> $sideEffects */
            $sideEffects = $transition->side_effects ?? [];

            $this->applySideEffects($model, $sideEffects);

            $this->recordWorkflowLog(
                $model,
                $tenantId,
                $entityType,
                $fromState,
                $toState,
                $transition
            );
        });
    }

    private function resolveCurrentState(Model $model): mixed
    {
        $currentState = $model->getRawOriginal('status');
        $status = $model->getAttribute('status');

        if (
            is_object($status)
            && property_exists($status, 'value')
        ) {
            $currentState = $status->value;
        }

        return $currentState;
    }

    /**
     * @return array{0: WorkflowState, 1: WorkflowState}
     */
    private function resolveStates(
        mixed $tenantId,
        string $entityType,
        mixed $currentState,
        string $toStateCode
    ): array {
        $fromState = WorkflowState::query()
            ->where('tenant_id', $tenantId)
            ->where('entity_type', $entityType)
            ->where('code', $currentState)
            ->where('is_active', true)
            ->first();

        $toState = WorkflowState::query()
            ->where('tenant_id', $tenantId)
            ->where('entity_type', $entityType)
            ->where('code', $toStateCode)
            ->where('is_active', true)
            ->first();

        if (! $fromState || ! $toState) {
            throw new Exception('Workflow state not found');
        }

        return [$fromState, $toState];
    }

    private function resolveTransition(
        mixed $tenantId,
        string $entityType,
        WorkflowState $fromState,
        WorkflowState $toState
    ): WorkflowTransition {
        $transition = WorkflowTransition::query()
            ->where('tenant_id', $tenantId)
            ->where('entity_type', $entityType)
            ->where('from_state_id', $fromState->id)
            ->where('to_state_id', $toState->id)
            ->where('is_active', true)
            ->first();

        if (! $transition) {
            throw new Exception('Invalid workflow transition');
        }

        return $transition;
    }

    private function recordWorkflowLog(
        Model $model,
        mixed $tenantId,
        string $entityType,
        WorkflowState $fromState,
        WorkflowState $toState,
        WorkflowTransition $transition
    ): void {
        WorkflowLog::create([
            'tenant_id' => $tenantId,
            'entity_type' => $entityType,
            'entity_id' => $model->getKey(),
            'from_state_id' => $fromState->id,
            'to_state_id' => $toState->id,
            'action' => $transition->action,
            'user_id' => auth()->id(),
            'payload' => [
                'transition_id' => $transition->id,
                'from' => $fromState->code,
                'to' => $toState->code,
            ],
        ]);
    }

    /**
     * @param array<string, array<string, mixed>> $conditions
     */
    private function validateConditions(
        Model $model,
        array $conditions
    ): void {
        foreach ($conditions as $field => $rules) {
            $actual = data_get($model, $field);

            foreach ($rules as $operator => $expected) {
                if (! $this->evaluateCondition(
                    $actual,
                    $operator,
                    $expected
                )) {
                    throw new Exception(
                        "Workflow condition failed for field: {$field}"
                    );
                }
            }
        }
    }

    private function evaluateCondition(
        mixed $actual,
        string $operator,
        mixed $expected
    ): bool {
        return match ($operator) {
            'min', 'max', 'eq', '=', 'neq', '!=', 'gt', '>',
            'gte', '>=', 'lt', '<', 'lte', '<=' => $this->evaluateComparison(
                $actual,
                $operator,
                $expected
            ),
            'in', 'not_in' => $this->evaluateCollection(
                $actual,
                $operator,
                $expected
            ),
            'exists' => $this->evaluateExists(
                $actual,
                $expected
            ),
            default => throw new Exception(
                "Unsupported workflow condition operator: {$operator}"
            ),
        };
    }

    private function evaluateComparison(
        mixed $actual,
        string $operator,
        mixed $expected
    ): bool {
        return match ($operator) {
            'min', 'gte', '>=' => $actual >= $expected,
            'max', 'lte', '<=' => $actual <= $expected,
            'eq', '=' => $actual == $expected,
            'neq', '!=' => $actual != $expected,
            'gt', '>' => $actual > $expected,
            'lt', '<' => $actual < $expected,
            default => false,
        };
    }

    private function evaluateCollection(
        mixed $actual,
        string $operator,
        mixed $expected
    ): bool {
        $values = (array) $expected;

        return $operator === 'in'
            ? in_array($actual, $values, true)
            : ! in_array($actual, $values, true);
    }

    private function evaluateExists(
        mixed $actual,
        mixed $expected
    ): bool {
        return $expected
            ? ! is_null($actual)
            : is_null($actual);
    }

    /**
     * @param array<int, array<string, mixed>> $sideEffects
     */
    private function applySideEffects(
        Model $model,
        array $sideEffects
    ): void {
        foreach ($sideEffects as $effect) {
            $type = $effect['type'] ?? null;

            if (! is_string($type) || $type === '') {
                continue;
            }

            match ($type) {
                'set' => $this->applySetEffect($model, $effect),
                'merge_meta' => $this->applyMergeMetaEffect($model, $effect),
                default => throw new Exception(
                    "Unsupported workflow side effect: {$type}"
                ),
            };
        }
    }

    /**
     * @param array<string, mixed> $effect
     */
    private function applySetEffect(
        Model $model,
        array $effect
    ): void {
        $field = $effect['field'] ?? null;

        if (! is_string($field) || $field === '') {
            throw new Exception(
                'Workflow set side effect requires a field.'
            );
        }

        /** @var array<string, mixed> $attributes */
        $attributes = [
            $field => $effect['value'] ?? null,
        ];

        $model->update($attributes);
    }

    /**
     * @param array<string, mixed> $effect
     */
    private function applyMergeMetaEffect(
        Model $model,
        array $effect
    ): void {
        $key = $effect['key'] ?? null;

        if (! is_string($key) || $key === '') {
            throw new Exception(
                'Workflow merge_meta side effect requires a key.'
            );
        }

        $currentMeta = $model->getAttribute('meta');

        if (! is_array($currentMeta)) {
            $currentMeta = [];
        }

        $currentMeta[$key] = $effect['value'] ?? null;

        /** @var array<string, mixed> $attributes */
        $attributes = [
            'meta' => $currentMeta,
        ];

        $model->update($attributes);
    }

    private function entityType(Model $model): string
    {
        return match (class_basename($model)) {
            'Policy' => 'policy',
            'Quote' => 'quote',
            'Claim' => 'claim',
            default => strtolower(class_basename($model)),
        };
    }
}
